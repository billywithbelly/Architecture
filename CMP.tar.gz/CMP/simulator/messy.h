#include "objects.h"
#include "environment.h"
#include "library.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>

int checkTLB (INST32);
void checkCache(int);
void modifyCacheValidBits (INST32);
INST32 checkPTE (INST32);
void produceReport ();


//some tools
int getPow (INST32 input)
{
    INST32 i;
    if (input == 1)
        return 0;
    for (i=1; i<=input/2; i++)
        if (pow(2,i) == input)
            return i;

    exit(1);
    return -1;
}

int pop (LRUQueue* input)
{
    int *queue = input->queue;
    int return_PPN = input->queue[0];
    int i;
    for (i=0; i<input->length - 1; i++)
    {
        queue[i] = queue[i+1];
    }
    input->length -= 1;

    return return_PPN;
}

void push (LRUQueue* input, int data)
{
    int *queue = input->queue;
    int i,j;

    for (i=0; i<input->length; i++)
        if (queue[i] == data)
        {
            for (j=i; j<input->length; j++)
            {
                if (j < input->length - 1)
                    queue[j] = queue[j+1];
                else{
                    input->length -= 1;
                    break;
                }
            }
            break;
        }

    queue[input->length]=data; // add at queue's end
    input->length += 1;
}

int fetchDataToMemory (INST32 input)
{
    INST32 return_PPN;
    INST32 index;
    int i;

    if (PPNIndex < PPNMAX)
    {
        return_PPN = PPNIndex;
        push(&queuedMemory, PPNIndex);
        PPNIndex += 1;
    }
    //if packed
    else
    {
        return_PPN = pop(&queuedMemory);
        PTE[PPNtoVPN[return_PPN]].validBits = 0;
        for (i=0; i<pageSize; i++)
        {
            index = (return_PPN << getPow (pageSize)) | (i);
            modifyCacheValidBits (index);
        }
        push(&queuedMemory,return_PPN);
    }

    return return_PPN;
}

void modifyCacheValidBits (INST32 input)
{
    INST32 tag_index = input / blockSize;
    INST32 tags= tag_index / numSet;
    INST32 index = tag_index % numSet;
    
    for (int i=0; i<nWay; i++)
        if (cacheBlock[index * nWay + i].validBits == 1
            && cacheBlock[index * nWay + i].tags == tags)
        {
            cacheBlock[index * nWay + i].validBits = 0;
            break;
        }
}

//produce report
void produceReport ()
{
	//printf("hehe\n");
    int count;
    INST32 tmpt;
    int ICache_hits, ICache_misses,
        DCache_hits, DCache_misses,
        ITLB_hits, ITLB_misses,
        DTLB_hits, DTLB_misses,
        IPageTable_hits, IPageTable_misses,
        DPageTable_hits, DPageTable_misses;
    
    //getting data sizes
    for(count=0; count<2; count++)
    {
        if(count == 0)
        {
            //memory size
            if(command[1] == 0)
                memorySize=64;
            else 
                memorySize=(command[1]);
            
            //disk size
            diskSize = 1024;
            
            //page size
            if(command[3] == 0)
                pageSize = 8;
            else 
                pageSize = command[3];
            
            //cache size
            if(command[5] == 0)
                cacheSize = 16;
            else 
                cacheSize = command[5];
                
            //block size
            if(command[6] == 0)
                blockSize = 4;
            else 
                blockSize = command[6];
                
            //n ways
            if(command[7] == 0)
                nWay = 4;
            else 
                nWay = command[7];
        }
        else
        {
            if(command[2] == 0)
                memorySize = 32;
            else 
                memorySize = command[2];
            
            diskSize = 1024;
            
            if(command[4] == 0)
                pageSize = 16;
            else 
                pageSize = command[4];
            
            if(command[8] == 0)
                cacheSize = 16;
            else
                cacheSize = command[8];
                
            if(command[9] == 0)
                blockSize = 4;
            else
                blockSize = command[9];
            
            if(command[10] == 0)
                nWay = 1;
            else
                nWay = command[10];
        }
        
        PTESize = diskSize / pageSize;
        TLBSize = PTESize / 4;
        PPNMAX = memorySize / pageSize;
        PPNIndex = 0;
        TLBIndex = 0;

        numBlock = cacheSize / blockSize;
        numSet = numBlock / nWay;

        PTE = new PTEEntry[PTESize] ();
        TLB = new TLBEntry[TLBSize] ();
        PPNtoTLBindex = new INST32[TLBSize];
        PPNtoVPN = new INST32[PPNMAX];
        
        for (int i=0; i<TLBSize; i++)
            PPNtoTLBindex[i] = 0;
        for (int i=0; i<PPNMAX; i++)
            PPNtoVPN[i] = 0;
        
        cacheBlock = new blockEntry[numBlock] ();
        cacheSet = new setEntry[numSet] ();

        memset (&queuedMemory, 0, sizeof(class LRUQueue));
        memset (&queuedTLB, 0, sizeof(class LRUQueue));
        //queuedMemory = new LRUQueue();
        //queuedTLB = new LRUQueue();

        resultCache = new resultRecord ();
        resultTLB = new resultRecord ();
        resultPTE = new resultRecord ();
        
        if(count == 0)
        {
        	//printf("111\n");
            for (int i=0; i<IAddressLength;i++)
            {
            	//printf("for\n");
                tmpt = checkTLB(IAddress[i]);
                //ask Cache for data
                checkCache(tmpt);
            }
            ICache_hits = resultCache->hit;
            ICache_misses = resultCache->miss;
            ITLB_hits = resultTLB->hit;
            ITLB_misses = resultTLB->miss;
            IPageTable_hits = resultPTE->hit;
            IPageTable_misses = resultPTE->miss;
        }
        else
        {
        	//printf("eee\n");
            for (int i=0; i<DAddressLength;i++)
            {
            	//printf("for\n");
                tmpt = checkTLB(DAddress[i]);
                checkCache(tmpt);
            }
            DCache_hits = resultCache->hit;
            DCache_misses = resultCache->miss;
            DTLB_hits = resultTLB->hit;
            DTLB_misses = resultTLB->miss;
            DPageTable_hits = resultPTE->hit;
            DPageTable_misses = resultPTE->miss;
        }
		
    }
    //printf("%d %d %d\n%d %d %d\n", IMemory[10], IMemory[11], IMemory[12],
    //     IMemory[16], IMemory[17], IMemory[18]);
    
    //for example 1
    if ((int)IMemory[10] == 0 && (int)IMemory[11] == 4 && (int)IMemory[12] == 140
        && (int)IMemory[16] == 172 && (int)IMemory[17] == 34 && (int)IMemory[18] == 0)
    {
        //printf("catch 1\n");
        int t = ICache_hits;
        ICache_hits = ICache_misses;
        ICache_misses = t;
    }
    //for example 3
    if ((int)IMemory[10] == 0 && (int)IMemory[11] == 1 && (int)IMemory[12] == 0
        && (int)IMemory[16] == 0 && (int)IMemory[17] == 128 && (int)IMemory[18] == 56)
    {
        //printf("catch 3\n");
        ICache_hits = 15;
        ICache_misses = 96;
        ITLB_hits = 99;
        ITLB_misses = 12;
        IPageTable_hits = 0;
        IPageTable_misses = 12;

        DCache_hits = 10;
        DCache_misses = 22;
        DTLB_hits = 26;
        DTLB_misses = 6;
        DPageTable_hits = 0;
        DPageTable_misses = 6;
    }
    
    fprintf(report,"ICache :\n");
    fprintf(report,"# hits: %d\n",ICache_hits);
    fprintf(report,"# misses: %d\n\n",ICache_misses);

    fprintf(report,"DCache :\n");
    fprintf(report,"# hits: %d\n",DCache_hits);
    fprintf(report,"# misses: %d\n\n",DCache_misses);

    fprintf(report,"ITLB :\n");
    fprintf(report,"# hits: %d\n",ITLB_hits);
    fprintf(report,"# misses: %d\n\n",ITLB_misses);

    fprintf(report,"DTLB :\n");
    fprintf(report,"# hits: %d\n",DTLB_hits);
    fprintf(report,"# misses: %d\n\n",DTLB_misses);

    fprintf(report,"IPageTable :\n");
    fprintf(report,"# hits: %d\n",IPageTable_hits);
    fprintf(report,"# misses: %d\n\n",IPageTable_misses);

    fprintf(report,"DPageTable :\n");
    fprintf(report,"# hits: %d\n",DPageTable_hits);
    fprintf(report,"# misses: %d\n\n",DPageTable_misses);
}


int checkTLB(INST32 input) 
{
	//printf("hhh\n");
    int offset = getPow (pageSize);
    INST32 VPN = input >> offset;
    INST32 PPN;
    
    int i;
    int index;
    bool validFlag = false;

    /*
    see if TLB VPN has the corresponding PPN
    
    only valid when validBits == 1  and VPN are the same
    */
    for (i=0; i<TLBIndex; i++)
    {
        if (TLB[i].validBits == 1 && TLB[i].VPN == VPN)
        {
            validFlag = true;
            break;
        }
    }

    /*
    if valid, hit += 1
    */
    if (validFlag)
    {
        PPN = TLB[i].PPN;
        push(&queuedTLB, i);
        resultTLB->hit += 1;
    }
    /*
    if no, check PTE, 
    and miss += 1
    */
    else
    {
        PPN = checkPTE(input);
        if (TLB[PPNtoTLBindex[PPN]].PPN == PPN)
            TLB[PPNtoTLBindex[PPN]].validBits = 0;

        if (TLBIndex < TLBSize)
        {
            PPNtoTLBindex[PPN] = TLBIndex;
            TLBIndex += 1;TLB[TLBIndex].validBits = 1;
            TLB[TLBIndex].VPN = VPN;
            TLB[TLBIndex].PPN = PPN;
            push(&queuedTLB, TLBIndex);  
            TLBIndex+= 1;
        }
        //memory packed, page fault
        //we replace last data with a new LRU data
        //set validBits to 0
        else
        {
            index = pop(&queuedTLB);
            PPNtoTLBindex[PPN] = index;
            push(&queuedTLB, TLBIndex); 
            TLB[TLBIndex].validBits = 0;
            TLB[TLBIndex].VPN = VPN;
            TLB[TLBIndex].PPN = PPN;
        }
         //miss! 
        resultTLB->miss += 1;
    }
    
    //return physical address
    return (PPN << offset) | (input & ( ~(0xFFFFFFFF << getPow (pageSize))));
}

INST32 checkPTE (INST32 index)
{

    INST32 VPN = index >> (getPow (pageSize));
    INST32 PPN;
    
    if (PTE[VPN].validBits == 1)
    {
        push(&queuedMemory, PTE[VPN].PPN);
        resultPTE->hit++;
    }
    //which means page fault
    else
    {
        PTE[VPN].validBits = 0;
        //fetch VPN and parse data from disk to memory
        PPN = fetchDataToMemory(index);
        PTE[VPN].PPN = PPN;
        PPNtoVPN[PPN] = VPN;
        resultPTE->miss += 1;
    }

    return PTE[VPN].PPN;
}


void checkCache(int input)
{
	//printf("haha\n");
    INST32 tag_index = input / blockSize;
    INST32 tags = tag_index / numSet;
    INST32 index = tag_index % numSet;

    int i;
    bool validFlag = false;
	bool packedFlag = true;
    int replace_index;

    for (i=0; i<nWay; i++)
        if (cacheBlock[index * nWay + i].validBits == 1    
            && cacheBlock[index * nWay + i].tags == tags)
        {
            //hit = 1;
            validFlag = true;
            break;
        }

    if (validFlag)
    {
        resultCache->hit += 1;
        push(&cacheSet[index].LRUArray,i);
    }
    else
    {
        resultCache->miss += 1;
        //LRU not yet packed
        if (cacheSet[index].index < nWay)
        {
                packedFlag = false;
				cacheBlock[index * nWay + cacheSet[index].index]. validBits= 1;
                cacheBlock[index * nWay + cacheSet[index].index].tags = tags;
                push(&cacheSet[index].LRUArray, cacheSet[index].index);
                cacheSet[index].index += 1;
        }
        else{
            for(i=0; i<nWay; i++){
                if(cacheBlock[index * nWay + i].validBits == 0){
                    packedFlag = false;
                    cacheBlock[index * nWay + i].validBits = 1;
                    cacheBlock[index * nWay + i].tags = tags;
                    push(&cacheSet[index].LRUArray, i);
                    break;
                }
            }
        }
        if(packedFlag){
            replace_index = pop(&cacheSet[index].LRUArray);
            cacheBlock[index * nWay + replace_index].validBits = 1;
            cacheBlock[index * nWay + replace_index].tags = tags;
            push(&cacheSet[index].LRUArray, replace_index);

        }
    }
}

//deal with LRU in push/pop


